# Node-JS-Simple-QR-Code-Generator-and-Download

npm package used : https://www.npmjs.com/package/qrcode

In this project user can generate the QR code and download the file.
# Test browser image
![img test](https://github.com/kcsrinivasa/Node-JS-Simple-QR-Code-Generator-and-Download/blob/main/store/Screen%20Shot%202020-12-25%20at%205.00.52%20PM.png)
